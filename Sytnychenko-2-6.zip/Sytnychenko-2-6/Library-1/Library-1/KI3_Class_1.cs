﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_1
{
    public class KI3_Class_1
    {
        public double F1(double x, double y)
        {
            return 2 * x - y;
        }
    }
}
