﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_2
{
    public static class KI3_Class_2
    {
        public static double F2(double x, double y)
        {
            return x * y;
        }
    }
}
