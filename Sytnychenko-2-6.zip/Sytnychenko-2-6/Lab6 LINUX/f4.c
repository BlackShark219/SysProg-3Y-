int f2(int x,int y);
int f4(int x,int y)
{
    return 3*f2(x,y)-2;
}
