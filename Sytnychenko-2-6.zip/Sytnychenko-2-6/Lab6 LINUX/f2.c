int f2(int x,int y)
{
    return x*y;
}
