int f1(int x,int y);
int f2(int x,int y);
int f3(int x,int y)
{
    return 6*f1(x,y)-3*f2(x,y);
}
