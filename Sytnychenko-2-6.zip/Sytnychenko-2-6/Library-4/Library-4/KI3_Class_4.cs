﻿using System;
using Library_2;

namespace Library_4
{
    public static class KI3_Class_4
    {
        public static double F4(double x, double y)
        {
            return 3 * KI3_Class_2.F2(x, y) - 2;
        }
    }
}
