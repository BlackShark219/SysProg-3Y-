﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.IO;
using Microsoft.Win32;
using System.Text.RegularExpressions;
using System.Data.Entity.Validation;
using System.Data.Entity;

namespace WS
{
    public partial class Service1 : ServiceBase
    {
        static string path = @"HKEY_LOCAL_MACHINE\Software\Task_Queue\Parameters";
        int taskduration = (int)Registry.GetValue(path, "Task_Execution_Duration", 60);
        int claimduration = (int)Registry.GetValue(path, "Task_Claim_Check_Period", 30);
        int qy = (int)Registry.GetValue(path, "Task_Execution_Quantity", 1);
        double percent = 0;
        bool upd = false;
        string p = "I";
        DateTime dateTime = DateTime.UtcNow.Date;
        List<Tasks> a = null;

        public Service1()
        {

            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Timer t = new Timer(claimduration * 1000);
            t.Elapsed += new ElapsedEventHandler(WorkingCycle);
            t.Enabled = true;
            System.Threading.Thread TH = new System.Threading.Thread(ParalelWorkingCycle);
            TH.Start();
            MakeLog("Service started");
        }


        private void WorkingCycle(object source, ElapsedEventArgs e)
        {
            try
            {
                using (PinokkioEntities1 db = new PinokkioEntities1())
                {

                    List<string> d = db.Tasks
                    .Select(y => y.Task_Name.Remove(9))
                    .ToList();
                    var allrec = db.Claims.ToList();
                    allrec.ForEach(x =>
                    {
                        if (!CheckTaskName(x.Task_Claim))
                        {
                            db.Claims.Attach(x);
                            db.Claims.Remove(x);
                            using (StreamWriter E = new StreamWriter("C:\\Windows\\Logs\\TaskQueue_" + dateTime.ToString("dd-MM-yyyy") + ".log", true))
                            {
                                E.WriteLine("ПОМИЛКА розміщення заявки {0}. Некоректний синтаксис ...", x.Task_Claim);
                            }
                            db.SaveChanges();

                        }
                        if (d.Contains(x.Task_Claim))
                        {
                            db.Claims.Attach(x);
                            db.Claims.Remove(x);
                            using (StreamWriter E = new StreamWriter("C:\\Windows\\Logs\\TaskQueue_" + dateTime.ToString("dd-MM-yyyy") + ".log", true))
                            {
                                E.WriteLine("ПОМИЛКА розміщення заявки {0}.Номер вже існує...", x.Task_Claim);
                            }
                            db.SaveChanges();
                        }
                    });
                    var rec = db.Claims.OrderBy(y => y.Task_Claim).First();
                    using (StreamWriter E = new StreamWriter("C:\\Windows\\Logs\\TaskQueue_" + dateTime.ToString("dd-MM-yyyy") + ".log", true))
                    {
                        E.WriteLine("Задача {0} успішно прийнята в обробку...", rec.Task_Claim);
                    }
                    Tasks t1 = new Tasks { Task_Name = rec.Task_Claim + "-[....................]-Queued" };
                    db.Tasks.Add(t1);
                    db.Claims.Attach(rec);
                    db.Claims.Remove(rec);
                    db.SaveChanges();

                }
            }
            catch (Exception a)
            {
                MakeErrorLog(a);
            }

        }

        private void Add()
        {
        }


        private void ParalelWorkingCycle()
        {

            Timer t = new Timer(1000);
            t.Elapsed += new ElapsedEventHandler(ChangeBar);
            t.Enabled = true;

        }

        public bool CheckTaskName(string p)
        {
            Regex R = new Regex(@"^Task_[0-9]{4}$");
            Match M = R.Match(p);
            return M.Success;
        }

        public void ChangeBar(object source, ElapsedEventArgs e)
        {
            using (PinokkioEntities1 db = new PinokkioEntities1())
            {
                //db.Configuration.AutoDetectChangesEnabled = false;

                try
                {
                    //if (a == null || a.Count() == 0)
                    //{
                    // MakeLog("Entered if");
                    List<Tasks> chk = db.Tasks.Where(x => !x.Task_Name.Contains("COMPLETED")).ToList();
                    List<Tasks> d = db.Tasks.Where(x => !x.Task_Name.Contains("COMPLETED")).OrderBy(y => y.Task_Name).Take(qy).ToList();
                    if (chk.Count() < qy)
                    {
                        a = chk;
                    }
                    else
                    {
                        a = d;
                    }
                    if (a.Count() == 0)
                    {
                        MakeLog("a is still null");
                        return;
                    }
                    foreach (var x in a)
                    {
                        MakeLog(x.Task_Name);
                    }


                    if (!upd)
                    {
                        a.ForEach(y =>
                        {

                            try
                            {
                                percent = Convert.ToDouble(y.Task_Name.Substring(47, 2));
                            }
                            catch
                            {
                                percent = 0;
                            }
                            AddPercent();
                           
                            if (percent >= 100)
                            {
                                y.Task_Name = y.Task_Name.Remove(9);
                                y.Task_Name = y.Task_Name.Insert(9, "-[IIIIIIIIIIIIIIIIIIII]-COMPLETED");
                                using (StreamWriter E = new StreamWriter("C:\\Windows\\Logs\\TaskQueue_" + dateTime.ToString("dd-MM-yyyy") + ".log", true))
                                {
                                    E.WriteLine("Задача {0} успішно ВИКОНАНА! " + DateTime.Now.ToString(), y.Task_Name.Remove(9));
                                }
                                upd = false;
                                percent = 0;
                                a = null;
                                db.Entry(y).State = EntityState.Modified;
                                db.SaveChanges();

                            }

                        });

                    }
                    else
                    {

                        a.ForEach(y =>
                        {

                            try
                            {
                                percent = Convert.ToDouble(y.Task_Name.Substring(47, 2));
                            }
                            catch
                            {
                                percent = 0;
                            }

                            AddPercent();
                            AddPercent();
                            if (taskduration > 100) AddPercent();
                            y.Task_Name = y.Task_Name.Remove(33);
                            y.Task_Name = y.Task_Name.Insert(33, "In progress - " + (int)percent + " percents");
                            int rm = (int)(percent / 5);
                            if (rm == 0) rm = 1;
                            y.Task_Name = y.Task_Name.Remove(11, rm);
                            y.Task_Name = y.Task_Name.Insert(11, RepeatForLoop(p, (int)(percent / 5)));
                            MakeLog(y.Task_Name);

                            if (percent >= 100)
                            {
                                y.Task_Name = y.Task_Name.Remove(9);
                                y.Task_Name = y.Task_Name.Insert(9, "-[IIIIIIIIIIIIIIIIIIII]-COMPLETED");
                                using (StreamWriter E = new StreamWriter("C:\\Windows\\Logs\\TaskQueue_" + dateTime.ToString("dd-MM-yyyy") + ".log", true))
                                {
                                    E.WriteLine("Задача {0} успішно ВИКОНАНА! " + DateTime.Now.ToString(), y.Task_Name.Remove(9));
                                }
                                upd = false;
                                percent = 0;
                                a = null;
                                db.Entry(y).State = EntityState.Modified;
                                db.SaveChanges();

                            }
                        });


                    }
                    a.ForEach(y => db.Entry(y).State = EntityState.Modified);
                    db.SaveChanges();
                    upd = !upd;

                }
                catch (Exception a)
                {
                    MakeErrorLog(a);
                    db.SaveChanges();
                }


            }

        }


        public double AddPercent()
        {
            double add = 100.0 / taskduration;
            return percent += add;
        }

        public string RepeatForLoop(string s, decimal n)
        {
            var result = s;
            MakeLog("N: " + n.ToString());
            for (var i = 0; i < n - 1; i++)
            {
                result += s;
            }
            MakeLog("res: " + result);
            return result;
        }
        public void MakeLog(string s)
        {
            using (StreamWriter E = new StreamWriter("C:\\Error.log", true))
            {
                E.WriteLine(DateTime.Now + " - " + s);
            }
        }

        public void MakeErrorLog(Exception a)
        {
            using (StreamWriter E = new StreamWriter("C:\\Error2.log", true))
            {
                E.WriteLine(DateTime.Now + a.Message + a.InnerException + a.StackTrace);
            }
        }

    }
}
