﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Xml.Linq;
using Microsoft.Win32;

namespace UDPServer
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }
        static string reg = @"SOFTWARE\Lab4";
        static string server = @"C:\\WORK\\UDPServerCons\\";
        static bool a;
        static string c = "";
        static int i = 0;
        static List<string> l1 = new List<string>();
        static string[] d;
        Thread T;
        bool mustStop;
        static RegistryKey WordsKey = Registry.LocalMachine.OpenSubKey(reg, true);
        protected override void OnStart(string[] args)
        {
            T = new Thread(WorkerThread);
            T.Start();
        }

        protected override void OnStop()
        {
            if ((T != null) && (T.IsAlive))
            {
                mustStop = true;
            }
        }

        void WorkerThread()
        {
            while (true)
            {

                IPAddress IP = IPAddress.Parse("192.168.0.105");
                IPEndPoint ipEndPoint = new IPEndPoint(IP, 54600);
                Socket S = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                try
                {
                    S.Bind(ipEndPoint);

                    while (true)
                    {
                        IPEndPoint L = new IPEndPoint(IP, 0);
                        EndPoint R = (EndPoint)(L);
                        byte[] D = new byte[10000];
                        int Receive = S.ReceiveFrom(D, ref R);
                        string Request = Encoding.GetEncoding(1251).GetString(D, 0, Receive);
                        if (Request.Contains("Button1"))
                        {
                            WriteRequest(Request, "Request-1.xml");
                            if (checkReg())
                            {
                                try
                                {
                                    if (i == 0)
                                    {
                                        string[] b = (string[])WordsKey.GetValue("Words");
                                        List<string> T = b.ToList();
                                        l1 = T;
                                        i++;
                                    }

                                    XDocument Doc = XDocument.Load(server + "Request-1.xml");
                                    foreach (XElement v in Doc.Element("Dictionary").Elements("Word"))
                                    {
                                        string[] b = (string[])WordsKey.GetValue("Words");
                                        if (!b.Contains(v.Value) && v.Value != "Button1")
                                        {
                                            l1.Add(v.Value);
                                            d = l1.ToArray();
                                        }

                                    }

                                    AddtoReg(d);




                                }
                                catch (Exception e)
                                {
                                    WriteRequest(e.Message + e.StackTrace, "Addreport.xml");
                                }
                                WriteRequest("Words have been added", "Response-1.xml");
                                string W = File.ReadAllText(server + "Response-1.xml", Encoding.GetEncoding(1251));
                                byte[] M = Encoding.GetEncoding(1251).GetBytes(W);
                                S.SendTo(M, R);
                            }
                            else
                            {
                                WriteRequest("Please create 'Words' subkey", "Response-1.xml");
                                string W = File.ReadAllText(server + "Response-1.xml", Encoding.GetEncoding(1251));
                                byte[] M = Encoding.GetEncoding(1251).GetBytes(W);
                                S.SendTo(M, R);
                            }

                        }
                        else if (Request.Contains("rad1"))
                        {
                            List<string> l2 = new List<string>();
                            string[] d2;
                            WriteRequest(Request, "Request-2.xml");
                            XDocument Doc = XDocument.Load(server + "Request-2.xml");
                            foreach (XElement v in Doc.Element("Dictionary").Elements("Word"))
                            {
                                if (!v.Value.Contains("Button2"))
                                {
                                    l2.Add(v.Value);
                                }

                            }
                            d2 = l2.OrderBy(x => x.Length).ToArray();
                            createXML(d2, "Response-2.xml");
                            string W = File.ReadAllText(server + "Response-2.xml", Encoding.GetEncoding(1251));
                            byte[] M = Encoding.GetEncoding(1251).GetBytes(W);
                            S.SendTo(M, R);
                        }
                        else if (Request.Contains("rad2"))
                        {
                            List<string> l2 = new List<string>();
                            string[] d2;
                            WriteRequest(Request, "Request-2.xml");
                            XDocument Doc = XDocument.Load(server + "Request-2.xml");
                            foreach (XElement v in Doc.Element("Dictionary").Elements("Word"))
                            {
                                if (!v.Value.Contains("Button2"))
                                {
                                    l2.Add(v.Value);
                                }

                            }
                            d2 = l2.OrderByDescending(x => x.Length).ToArray();
                            l2.Clear();
                            createXML(d2, "Response-2.xml");
                            string W = File.ReadAllText(server + "Response-2.xml", Encoding.GetEncoding(1251));
                            byte[] M = Encoding.GetEncoding(1251).GetBytes(W);
                            S.SendTo(M, R);
                        }









                    }
                }
                catch (Exception e)
                {
                    WriteRequest(e.Message, "Error.xml");
                }
            }
        }

        private static void WriteLog(string z)
        {
            using (StreamWriter F = new StreamWriter("C:\\WORK\\UDP-Req.log", true))
            {
                F.WriteLine(DateTime.Now + "  " + z);
            }
        }


        private static void WriteRequest(string z, string path)
        {
            using (StreamWriter F = new StreamWriter("C:\\WORK\\UDPServerCons\\" + path, false, Encoding.GetEncoding(1251)))
            {
                F.WriteLine(z);
            }
        }

        public static bool checkReg()
        {
            try
            {
                RegistryKey winLogonKey = Registry.LocalMachine.OpenSubKey(reg, true);
                return (winLogonKey.GetValueNames().Contains("Words"));

            }
            catch (Exception e)
            {
                WriteRequest(e.Message, "ErrorRegistry.xml");
                return a;
            }


        }

        public static void AddtoReg(string[] s)
        {

            WordsKey.SetValue("Words", s, RegistryValueKind.MultiString);
        }

        static public void MakeLog(string s, string path)
        {
            using (StreamWriter E = new StreamWriter(server + path, true))
            {
                E.WriteLine(DateTime.Now + " - " + s + Environment.NewLine);
            }
        }

        static string createXML(string[] words, string name)
        {
            string path = @"xmlRequest.xml";
            XDocument xmlDoc = new XDocument(new XDeclaration("1.0", "windows-1251", "yes"));
            XElement document = new XElement("Dictionary");
            foreach (var word in words)
            {
                XElement resOne = new XElement("Word", word);
                document.Add(resOne);
            }

            xmlDoc.Add(document);
            xmlDoc.Save(server + name);
            return path;
        }
    }
}
