﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace UDPClient
{
    public partial class Form1 : Form
    {
        protected string Answer;
        string A;
        string clientpath= @"C:\\WORK\\UDPClient\\";
        char delimiterChar = ',';
        int req = 0;
        public Form1()
        {
            InitializeComponent();

        }



        public string Speaking(string XmlPath)
        {
            string F = File.ReadAllText(XmlPath, Encoding.GetEncoding(1251));
            byte[] M = Encoding.GetEncoding(1251).GetBytes(F);
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Parse("192.168.0.105"), 54600);
            byte[] bytes = new byte[10000];
            using (Socket S = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
            {
                S.Connect(ipEndPoint);
                S.Send(M);
                int bytesRec = S.Receive(bytes);
                Answer = Encoding.GetEncoding(1251).GetString(bytes, 0, bytesRec);
                if (Answer.Contains("Words"))
                {
                    WriteRequest(Answer, "Response-1.xml");
                }
                else
                {
                    WriteRequest(Answer, "Response-2.xml");
                }

                S.Shutdown(SocketShutdown.Both);
                return Answer;
                
            }
        }

        private static void WriteRequest(string z, string path)
        {
            using (StreamWriter F = new StreamWriter("C:\\WORK\\UDPClient\\" + path, false, Encoding.GetEncoding(1251)))
            {
                F.WriteLine(z);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.TextLength!=0) 
            {   
                string[] words = textBox1.Text.Split(delimiterChar);
                createXML(words,"Request-1.xml","Button1");
                textBox1.Clear();
                Speaking(clientpath+"Request-1.xml");
            }
            else
            {
                MessageBox.Show("Please enter some words");
                return;
            }

            if (Answer.Contains("create") && Answer != null)
            {
                    MessageBox.Show(Answer);               
            }
        }

        string createXML(string[] words,string name,string button)
        {
            string path = @"xmlRequest.xml";
            XDocument xmlDoc = new XDocument(new XDeclaration("1.0", "windows-1251", "yes"));      
            XElement document = new XElement("Dictionary");
            XElement option = new XElement("Word", button);
            document.Add(option);
            foreach (var word in words)
            {
                XElement resOne = new XElement("Word", word);
                document.Add(resOne);
            }

            xmlDoc.Add(document);
            xmlDoc.Save(clientpath + name);
            return path;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("Choose at least one option");
                return;
            }
            else
            {
                textBox2.Enabled = true;
            }
            string[] words = textBox2.Text.Split(delimiterChar);

            if (radioButton1.Checked)
            {
                List<string> l2 = new List<string>();
                string s = "";
                createXML(words, "Request-2.xml", "Button2rad1");
                textBox2.Clear();
                Speaking(clientpath + "Request-2.xml");
                XDocument Doc = XDocument.Load(clientpath + "Response-2.xml");
                foreach (XElement v in Doc.Element("Dictionary").Elements("Word"))
                {
                        l2.Add(v.Value);
                }
                l2.ForEach(x => s += x+Environment.NewLine);
                MessageBox.Show(s);
            }
            else
            {
                List<string> l2 = new List<string>();
                string s = "";
                createXML(words, "Request-2.xml", "Button2rad2");
                textBox2.Clear();
                Speaking(clientpath + "Request-2.xml");
                XDocument Doc = XDocument.Load(clientpath + "Response-2.xml");
                foreach (XElement v in Doc.Element("Dictionary").Elements("Word"))
                {
                    l2.Add(v.Value);
                }
                l2.ForEach(x => s += x + Environment.NewLine);
                MessageBox.Show(s);
            }
            
           
        }


    }
}
